package com.example.controller;

import com.example.model.Customer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Controller
public class CustomerController {

    @Value("${api.baseurl}")
    private String apiBaseUrl; // Read API base URL from application.properties

    private String bearerToken = null;
    private RestTemplate restTemplate = new RestTemplate();

    // Login Page
    @GetMapping("/login")
    public String loginPage() {
        return "login"; // Renders the login.html template
    }

    @PostMapping("/login")
    public String login(@RequestParam("login_id") String loginId, @RequestParam("password") String password) {
        // Make a POST request to authenticate and obtain the bearer token
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Prepare the request body
        String requestBody = "{\"login_id\":\"" + loginId + "\",\"password\":\"" + password + "\"}";

        HttpEntity<String> request = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(apiBaseUrl + "/assignment_auth.jsp", HttpMethod.POST, request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                bearerToken = response.getBody();
                return "redirect:/customerList"; // Redirect to Customer List page on successful login
            } else {
                // Handle authentication failure
                return "login"; // Redirect back to the login page with an error message
            }
        } catch (HttpClientErrorException ex) {
            // Handle HTTP client exceptions (e.g., 401 Unauthorized)
            return "login"; // Redirect back to the login page with an error message
        }
    }

    // Customer List Page
    @GetMapping("/customerList")
    public String customerList(Model model) {
        if (bearerToken != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(bearerToken);
            HttpEntity<String> entity = new HttpEntity<>(headers);

            try {
                ResponseEntity<Customer[]> response = restTemplate.exchange(apiBaseUrl + "/assignment.jsp?cmd=get_customer_list", HttpMethod.GET, entity, Customer[].class);

                if (response.getStatusCode() == HttpStatus.OK) {
                    List<Customer> customers = Arrays.asList(response.getBody());
                    model.addAttribute("customers", customers);
                }
            } catch (HttpClientErrorException ex) {
                // Handle HTTP client exceptions (e.g., 401 Unauthorized)
                return "login"; // Redirect back to the login page with an error message
            }
        } else {
            // Handle authentication failure (bearer token not available)
            return "login"; // Redirect back to the login page
        }

        return "customerList"; // Renders the customerList.html template
    }

    // Add New Customer Page
    @GetMapping("/addCustomer")
    public String addCustomerPage() {
        return "addCustomer"; // Renders the addCustomer.html template
    }

    @PostMapping("/addCustomer")
    public String addCustomer(@ModelAttribute Customer customer) {
        if (bearerToken != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(bearerToken);

            // Prepare the request body
            String requestBody = "{\"cmd\":\"create\",\"first_name\":\"" + customer.getFirst_name() + "\",\"last_name\":\"" + customer.getLast_name() + "\",\"street\":\"" + customer.getStreet() + "\",\"address\":\"" + customer.getAddress() + "\",\"city\":\"" + customer.getCity() + "\",\"state\":\"" + customer.getState() + "\",\"email\":\"" + customer.getEmail() + "\",\"phone\":\"" + customer.getPhone() + "\"}";

            HttpEntity<String> request = new HttpEntity<>(requestBody, headers);

            try {
                ResponseEntity<String> response = restTemplate.exchange(apiBaseUrl + "/assignment.jsp", HttpMethod.POST, request, String.class);

                if (response.getStatusCode() == HttpStatus.CREATED) {
                    return "redirect:/customerList"; // Redirect to Customer List page after adding a new customer
                } else {
                    // Handle customer creation failure
                    return "addCustomer"; // Redirect back to the addCustomer page with an error message
                }
            } catch (HttpClientErrorException ex) {
                // Handle HTTP client exceptions (e.g., 401 Unauthorized, 400 Bad Request)
                return "addCustomer"; // Redirect back to the addCustomer page with an error message
            }
        } else {
            // Handle authentication failure (bearer token not available)
            return "login"; // Redirect back to the login page
        }
    }

 // Edit Customer Page
    @GetMapping("/edit/{uuid}")
    public String editCustomerPage(@PathVariable String uuid, Model model) {
        if (bearerToken != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(bearerToken);
            HttpEntity<String> entity = new HttpEntity<>(headers);

            try {
                ResponseEntity<Customer> response = restTemplate.exchange(apiBaseUrl + "/assignment.jsp?cmd=get_customer&uuid=" + uuid, HttpMethod.GET, entity, Customer.class);

                if (response.getStatusCode() == HttpStatus.OK) {
                    Customer customer = response.getBody();
                    model.addAttribute("customer", customer);
                    return "editCustomer"; // Renders the editCustomer.html template with customer details
                } else {
                    // Handle customer retrieval failure
                    return "customerList"; // Redirect back to the customer list page with an error message
                }
            } catch (HttpClientErrorException ex) {
                // Handle HTTP client exceptions (e.g., 401 Unauthorized)
                return "customerList"; // Redirect back to the customer list page with an error message
            }
        } else {
            // Handle authentication failure (bearer token not available)
            return "login"; // Redirect back to the login page
        }
    }

    // Handle form submission for updating a customer
    @PostMapping("/edit/{uuid}")
    public String updateCustomer(@PathVariable String uuid, @ModelAttribute Customer customer) {
        if (bearerToken != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(bearerToken);

            // Prepare the request body
            String requestBody = "{\"cmd\":\"update\",\"uuid\":\"" + uuid + "\",\"first_name\":\"" + customer.getFirst_name() + "\",\"last_name\":\"" + customer.getLast_name() + "\",\"street\":\"" + customer.getStreet() + "\",\"address\":\"" + customer.getAddress() + "\",\"city\":\"" + customer.getCity() + "\",\"state\":\"" + customer.getState() + "\",\"email\":\"" + customer.getEmail() + "\",\"phone\":\"" + customer.getPhone() + "\"}";

            HttpEntity<String> request = new HttpEntity<>(requestBody, headers);

            try {
                ResponseEntity<String> response = restTemplate.exchange(apiBaseUrl + "/assignment.jsp", HttpMethod.POST, request, String.class);

                if (response.getStatusCode() == HttpStatus.OK) {
                    return "redirect:/customerList"; // Redirect to Customer List page after updating the customer
                } else {
                    // Handle customer update failure
                    return "editCustomer"; // Redirect back to the editCustomer page with an error message
                }
            } catch (HttpClientErrorException ex) {
                // Handle HTTP client exceptions (e.g., 401 Unauthorized, 400 Bad Request)
                return "editCustomer"; // Redirect back to the editCustomer page with an error message
            }
        } else {
            // Handle authentication failure (bearer token not available)
            return "login"; // Redirect back to the login page
        }
    }
 // Delete Customer
    @GetMapping("/delete/{uuid}")
    public String deleteCustomer(@PathVariable String uuid) {
        if (bearerToken != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(bearerToken);
            HttpEntity<String> entity = new HttpEntity<>(headers);

            try {
                ResponseEntity<Void> response = restTemplate.exchange(apiBaseUrl + "/assignment.jsp?cmd=delete&uuid=" + uuid, HttpMethod.POST, entity, Void.class);

                if (response.getStatusCode() == HttpStatus.OK) {
                    return "redirect:/customerList"; // Redirect to Customer List page after deleting a customer
                } else {
                    // Handle customer deletion failure
                    return "customerList"; // Redirect back to the customer list page with an error message
                }
            } catch (HttpClientErrorException ex) {
                // Handle HTTP client exceptions (e.g., 401 Unauthorized, 400 Bad Request)
                return "customerList"; // Redirect back to the customer list page with an error message
            }
        } else {
            // Handle authentication failure (bearer token not available)
            return "login"; // Redirect back to the login page
        }
    }


}
