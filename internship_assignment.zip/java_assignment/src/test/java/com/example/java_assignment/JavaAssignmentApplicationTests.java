package com.example.java_assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
